from aiogram import Router, F
from aiogram.types import Message
from aiogram.fsm.context import FSMContext


from states.state_menu import ShogirdKerakState

shogird_router = Router()